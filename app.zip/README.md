# aws-deploy








## Process:

1. Enter AWS education, and sign in with your account.
2. Accept the terms and conditions.
3. Go to AWS console.
4. Check all the services from AWS, choose Elastic Beanstalk.
5. Create new application.
6. 